package com.alamkanak.weekview;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.TextPaint;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static com.alamkanak.weekview.DateUtils.today;
import static java.lang.Math.max;
import static java.lang.Math.min;
import static java.util.Calendar.DAY_OF_WEEK;

class WeekViewDrawingConfig {
	WeakReference<WeekViewConfig> config;

	Paint timeTextTopPaint;
	Paint timeTextBottomPaint;
	Paint timeCaptionPaint;
	float timeTextWidth;
	float timeCaptionWidth;
	float timeTextHeight;
	float timeCaptionHeight;
	float timeColumnWidth;

	Paint headerTextPaint;
	float headerTextHeight;
	Paint headerSecondaryTextPaint;
	float headerSecondaryTextHeight;
	float headerHeight;

	PointF currentOrigin = new PointF(0f, 0f);
	Paint headerBackgroundPaint;
	float widthPerDay;
	Paint dayBackgroundPaint;
	Paint hourSeparatorPaint;
	Paint daySeparatorPaint;
	float headerMarginBottom;

	Paint todayBackgroundPaint;
	Paint timeColumnSeparatorPaint;
	Paint nowLinePaint;
	Paint nowDotPaint;
	Paint todayHeaderTextPaint;
	Paint todayHeaderSecondaryTextPaint;
	TextPaint eventTextPaint;
	TextPaint eventTopPaint;
	TextPaint eventBottomPaint;
	Paint headerColumnBackgroundPaint;
	int newHourHeight = -1;
	DateTimeInterpreter dateTimeInterpreter;
	private Paint futureBackgroundPaint;
	private Paint pastBackgroundPaint;
	private Paint futureWeekendBackgroundPaint;
	private Paint pastWeekendBackgroundPaint;

	WeekViewDrawingConfig(Context context, WeekViewConfig config) {
		this.config = new WeakReference<>(config);

		// Measure settings for time column.
		timeTextTopPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		timeTextTopPaint.setTextAlign(Paint.Align.LEFT);
		timeTextTopPaint.setTextSize(config.timeColumnTextSize);
		timeTextTopPaint.setColor(config.timeColumnTextColor);

		timeTextBottomPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		timeTextBottomPaint.setTextAlign(Paint.Align.RIGHT);
		timeTextBottomPaint.setTextSize(config.timeColumnTextSize);
		timeTextBottomPaint.setColor(config.timeColumnTextColor);

		final Rect rect = new Rect();
		timeTextTopPaint.getTextBounds("00 PM", 0, "00 PM".length(), rect);
		timeTextHeight = rect.height();
		initTimeTextWidth(context);

		timeCaptionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		timeCaptionPaint.setTextAlign(Paint.Align.CENTER);
		timeCaptionPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
		timeCaptionPaint.setTextSize(config.timeColumnCaptionSize);
		timeCaptionPaint.setColor(config.timeColumnCaptionColor);

		timeCaptionPaint.getTextBounds("00 PM", 0, "00 PM".length(), rect);
		timeCaptionHeight = rect.height();
		initTimeCaptionWidth();

		// Measure settings for header row.
		headerTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		headerTextPaint.setColor(config.headerRowTextColor);
		headerTextPaint.setTextAlign(Paint.Align.CENTER);
		headerTextPaint.setTextSize(config.headerRowTextSize);
		headerTextPaint.getTextBounds("00 PM", 0, "00 PM".length(), rect);
		headerTextHeight = rect.height();
		headerTextPaint.setTypeface(Typeface.DEFAULT_BOLD);

		headerSecondaryTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		headerSecondaryTextPaint.setColor(config.headerRowTextColor);
		headerSecondaryTextPaint.setTextAlign(Paint.Align.CENTER);
		headerSecondaryTextPaint.setTextSize(config.headerRowSecondaryTextSize);
		headerSecondaryTextPaint.getTextBounds("00 PM", 0, "00 PM".length(), rect);
		headerSecondaryTextHeight = rect.height();
		headerSecondaryTextPaint.setTypeface(Typeface.DEFAULT);

		// Prepare header background paint.
		headerBackgroundPaint = new Paint();
		headerBackgroundPaint.setColor(config.headerRowBackgroundColor);

		// Prepare day background color paint.
		dayBackgroundPaint = new Paint();
		dayBackgroundPaint.setColor(config.dayBackgroundColor);
		futureBackgroundPaint = new Paint();
		futureBackgroundPaint.setColor(config.futureBackgroundColor);
		pastBackgroundPaint = new Paint();
		pastBackgroundPaint.setColor(config.pastBackgroundColor);
		futureWeekendBackgroundPaint = new Paint();
		futureWeekendBackgroundPaint.setColor(config.futureWeekendBackgroundColor);
		pastWeekendBackgroundPaint = new Paint();
		pastWeekendBackgroundPaint.setColor(config.pastWeekendBackgroundColor);

		// Prepare time column separator.
		timeColumnSeparatorPaint = new Paint();
		timeColumnSeparatorPaint.setColor(config.timeColumnSeparatorColor);
		timeColumnSeparatorPaint.setStrokeWidth(config.timeColumnSeparatorStrokeWidth);

		// Prepare hour separator color paint.
		hourSeparatorPaint = new Paint();
		hourSeparatorPaint.setStyle(Paint.Style.STROKE);
		hourSeparatorPaint.setStrokeWidth(config.hourSeparatorStrokeWidth);
		hourSeparatorPaint.setColor(config.hourSeparatorColor);

		// Prepare day separator color paint.
		daySeparatorPaint = new Paint();
		daySeparatorPaint.setStyle(Paint.Style.STROKE);
		daySeparatorPaint.setStrokeWidth(config.daySeparatorStrokeWidth);
		daySeparatorPaint.setColor(config.daySeparatorColor);

		// Prepare the "now" line color paint
		nowLinePaint = new Paint();
		nowLinePaint.setStrokeWidth(config.nowLineStrokeWidth);
		nowLinePaint.setColor(config.nowLineColor);

		// Prepare the "now" dot paint
		nowDotPaint = new Paint();
		nowDotPaint.setStyle(Paint.Style.FILL);
		nowDotPaint.setStrokeWidth(config.nowLineDotRadius);
		nowDotPaint.setColor(config.nowLineDotColor);

		// Prepare today background color paint.
		todayBackgroundPaint = new Paint();
		todayBackgroundPaint.setColor(config.todayBackgroundColor);

		// Prepare today header text color paint.
		todayHeaderTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		todayHeaderTextPaint.setTextAlign(Paint.Align.CENTER);
		todayHeaderTextPaint.setTextSize(config.headerRowTextSize);
		todayHeaderTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
		todayHeaderTextPaint.setColor(config.todayHeaderTextColor);

		todayHeaderSecondaryTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		todayHeaderSecondaryTextPaint.setTextAlign(Paint.Align.CENTER);
		todayHeaderSecondaryTextPaint.setTextSize(config.headerRowSecondaryTextSize);
		todayHeaderSecondaryTextPaint.setTypeface(Typeface.DEFAULT);
		todayHeaderSecondaryTextPaint.setColor(config.todayHeaderTextColor);

		// Prepare event background color.
		//eventBackgroundPaint = new Paint();
		//eventBackgroundPaint.setColor(Color.rgb(174, 208, 238));

		// Prepare header column background color.
		headerColumnBackgroundPaint = new Paint();
		headerColumnBackgroundPaint.setColor(config.timeColumnBackgroundColor);

		// Prepare event text size and color.
		eventTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.LINEAR_TEXT_FLAG);
		eventTextPaint.setTextAlign(Paint.Align.CENTER); // TODO: Make alignment configurable
		eventTextPaint.setStyle(Paint.Style.FILL);
		eventTextPaint.setColor(config.eventTextColor);
		eventTextPaint.setTextSize(config.eventTextSize);
		eventTextPaint.setTypeface(Typeface.DEFAULT_BOLD);

		// Prepare event text size and color.
		eventTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.LINEAR_TEXT_FLAG);
		eventTopPaint.setTextAlign(Paint.Align.LEFT); // TODO: Make alignment configurable
		eventTopPaint.setStyle(Paint.Style.FILL);
		eventTopPaint.setColor(config.eventTextColor);
		eventTopPaint.setTextSize(config.eventSecondaryTextSize);

		// Prepare event text size and color.
		eventBottomPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.LINEAR_TEXT_FLAG);
		eventBottomPaint.setTextAlign(Paint.Align.RIGHT); // TODO: Make alignment configurable
		eventBottomPaint.setStyle(Paint.Style.FILL);
		eventBottomPaint.setColor(config.eventTextColor);
		eventBottomPaint.setTextSize(config.eventSecondaryTextSize);
	}

	void moveCurrentOriginIfFirstDraw(WeekViewConfig config) {
		// If the week view is being drawn for the first time, then consider the first day of the week.
		final Calendar today = today();
		final boolean isWeekView = config.numberOfVisibleDays >= 7;
		final boolean currentDayIsNotToday = today.get(DAY_OF_WEEK) != config.firstDayOfWeek;
		if (isWeekView && currentDayIsNotToday && config.showFirstDayOfWeekFirst) {
			int difference = today.get(DAY_OF_WEEK) - config.firstDayOfWeek;
			currentOrigin.x += (widthPerDay/* + config.columnGap*/) * difference;
		}
	}

	void refreshAfterZooming(WeekViewConfig config) {
		if (newHourHeight > 0) {
			if (newHourHeight < config.effectiveMinHourHeight) {
				newHourHeight = config.effectiveMinHourHeight;
			} else if (newHourHeight > config.maxHourHeight) {
				newHourHeight = config.maxHourHeight;
			}

			currentOrigin.y = (currentOrigin.y / config.hourHeight) * newHourHeight;
			config.hourHeight = newHourHeight;
			newHourHeight = -1;
		}
	}

	void updateVerticalOrigin(WeekViewConfig config) {
		final int height = WeekView.getViewHeight();

		// If the new currentOrigin.y is invalid, make it valid.
		final float dayHeight = config.hourHeight * config.hoursPerDay();
		final float headerHeight = this.headerHeight + config.headerRowPadding * 2 + headerMarginBottom;

		final float potentialNewVerticalOrigin = height - (dayHeight + headerHeight);

		currentOrigin.y = max(currentOrigin.y, potentialNewVerticalOrigin);
		currentOrigin.y = min(currentOrigin.y, 0);
	}

	void resetOrigin() {
		currentOrigin = new PointF(0, 0);
	}

	void setTextSize(int textSize) {
		todayHeaderTextPaint.setTextSize(textSize);
		headerTextPaint.setTextSize(textSize);
		timeTextTopPaint.setTextSize(textSize);
	}

	void setDateTimeInterpreter(DateTimeInterpreter dateTimeInterpreter, Context context) {
		this.dateTimeInterpreter = dateTimeInterpreter;
		initTimeTextWidth(context);
	}

	Paint getPastBackgroundPaint(boolean useWeekendColor) {
		return useWeekendColor ? pastWeekendBackgroundPaint : pastBackgroundPaint;
	}

	Paint getFutureBackgroundPaint(boolean useWeekendColor) {
		return useWeekendColor ? futureWeekendBackgroundPaint : futureBackgroundPaint;
	}

	Paint getTodayBackgroundPaint(boolean isToday) {
		return isToday ? todayBackgroundPaint : dayBackgroundPaint;
	}

	/**
	 * Initialize time column width. Calculate value with all possible hours (supposed widest text).
	 */
	private void initTimeTextWidth(Context context) {
		final DateTimeInterpreter interpreter = getDateTimeInterpreter(context);

		timeTextWidth = timeTextTopPaint.measureText(interpreter.interpretTime(11 * 60 + 11));
	}

	private void initTimeCaptionWidth() {
		timeCaptionWidth = timeCaptionPaint.measureText("100");
	}

	DateTimeInterpreter getDateTimeInterpreter(Context context) {
		if (dateTimeInterpreter == null) {
			dateTimeInterpreter = buildDefaultDateTimeInterpreter(context);
		}

		return dateTimeInterpreter;
	}

	private DateTimeInterpreter buildDefaultDateTimeInterpreter(final Context context) {
		return new DateTimeInterpreter() {
			private SimpleDateFormat sdfDate = new SimpleDateFormat("EEE", Locale.getDefault());
			private SimpleDateFormat sdfSecondaryDate = new SimpleDateFormat("d. MMM", Locale.getDefault());
			private SimpleDateFormat sdfTime = DateUtils.getTimeFormat(context);
			private Calendar calendar = Calendar.getInstance();

			@Override
			public String interpretDate(Calendar date) {
				try {
					return sdfDate.format(date.getTime()).toUpperCase();
				} catch (Exception e) {
					e.printStackTrace();
					return "";
				}
			}

			@Override
			public String interpretSecondaryDate(Calendar date) {
				try {
					return sdfSecondaryDate.format(date.getTime()).toUpperCase();
				} catch (Exception e) {
					e.printStackTrace();
					return "";
				}
			}

			@Override
			public String interpretTime(int minutes) {
				calendar.clear();
				calendar.add(Calendar.MINUTE, minutes);

				try {
					return sdfTime.format(calendar.getTime());
				} catch (Exception e) {
					e.printStackTrace();
					return "";
				}
			}
		};
	}

}
