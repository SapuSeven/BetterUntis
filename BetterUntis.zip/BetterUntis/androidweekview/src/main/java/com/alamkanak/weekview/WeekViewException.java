package com.alamkanak.weekview;

public class WeekViewException extends IllegalStateException {

    public WeekViewException(String message) {
        super(message);
    }

}
