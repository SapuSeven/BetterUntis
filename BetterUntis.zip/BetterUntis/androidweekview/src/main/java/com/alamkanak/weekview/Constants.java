package com.alamkanak.weekview;

class Constants {
    static long DAY_IN_MILLIS = 1000L * 60L * 60L * 24L;
}
