package com.sapuseven.untis.annotations

annotation class Table(val name: String)
