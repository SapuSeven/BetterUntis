package com.sapuseven.untis.helpers.timetable

import com.sapuseven.untis.data.connectivity.UntisApiConstants
import com.sapuseven.untis.data.connectivity.UntisAuthentication
import com.sapuseven.untis.data.connectivity.UntisRequest
import com.sapuseven.untis.data.databases.User
import com.sapuseven.untis.data.timetable.PeriodData
import com.sapuseven.untis.data.timetable.TimegridItem
import com.sapuseven.untis.helpers.DateTimeUtils
import com.sapuseven.untis.interfaces.TimetableDisplay
import com.sapuseven.untis.models.untis.UntisDate
import com.sapuseven.untis.models.untis.params.TimetableParams
import com.sapuseven.untis.models.untis.response.TimetableResponse
import com.sapuseven.untis.models.untis.timetable.Period
import kotlinx.coroutines.experimental.android.UI
import kotlinx.coroutines.experimental.launch
import kotlinx.coroutines.experimental.withContext
import kotlinx.serialization.json.JSON

class TimetableLoader(private val timetableDisplay: TimetableDisplay,
                      private val user: User,
                      private val timetableDatabaseInterface: TimetableDatabaseInterface) {
	private var api: UntisRequest = UntisRequest()
	private var query: UntisRequest.UntisRequestQuery = UntisRequest.UntisRequestQuery()

	fun load(startDate: UntisDate, endDate: UntisDate, id: Int, type: String) {
		launch {
			query.url = user.apiUrl ?: UntisApiConstants.DEFAULT_PROTOCOL + user.url + UntisApiConstants.DEFAULT_WEBUNTIS_PATH
			query.school = user.school

			val params = TimetableParams(
					startDate,
					endDate,
					user.masterDataTimestamp,
					0,
					emptyList(),
					id,
					type,
					UntisAuthentication.getAuthObject(user.user, user.key)
			)

			query.data.method = UntisApiConstants.METHOD_GET_TIMETABLE
			query.data.params = listOf(params)

			val (_, _, userDataResult) = api.request(query)

			userDataResult.fold({ data ->
				val untisResponse = JSON.parse<TimetableResponse>(data)

				if (untisResponse.result != null) {
					withContext(UI) {
						timetableDisplay.addData(untisResponse.result.timetable.periods.map { periodToTimegridItem(it, type) })

						// TODO: Interpret masterData in the response
					}
				} else {
					// TODO: Show error message
				}
			}, { error ->
				println("An error happened: ${error.exception}") // TODO: Localize and notify user
			})
		}
	}

	private fun periodToTimegridItem(period: Period, type: String): TimegridItem {
		return TimegridItem(
				period.id.toLong(),
				DateTimeUtils.isoDateTimeNoSeconds().parseLocalDateTime(period.startDateTime),
				DateTimeUtils.isoDateTimeNoSeconds().parseLocalDateTime(period.endDateTime),
				type,
				PeriodData(timetableDatabaseInterface, period)
		)
	}
}