package com.sapuseven.untis.adapters

import com.sapuseven.untis.models.UntisSchoolInfo

class SchoolSearchAdapterItem(var untisSchoolInfo: UntisSchoolInfo?)
