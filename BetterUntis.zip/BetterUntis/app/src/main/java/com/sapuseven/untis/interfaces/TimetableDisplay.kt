package com.sapuseven.untis.interfaces

import com.sapuseven.untis.data.timetable.TimegridItem

interface TimetableDisplay {
	fun addData(items: List<TimegridItem>)
}