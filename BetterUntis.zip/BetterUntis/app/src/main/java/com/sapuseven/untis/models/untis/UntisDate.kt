package com.sapuseven.untis.models.untis

import kotlinx.serialization.*

@Serializable
class UntisDate(
		val date: String
) {
	@Serializer(forClass = UntisDate::class)
	companion object : KSerializer<UntisDate> {
		override fun save(output: KOutput, obj: UntisDate) {
			output.writeStringValue(obj.date)
		}

		override fun load(input: KInput): UntisDate {
			return UntisDate(input.readStringValue())
		}
	}

	override fun toString(): String {
		return date
	}
}