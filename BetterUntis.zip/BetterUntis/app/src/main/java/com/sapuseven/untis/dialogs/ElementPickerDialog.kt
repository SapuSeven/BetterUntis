package com.sapuseven.untis.dialogs

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.support.design.widget.TextInputEditText
import android.support.design.widget.TextInputLayout
import android.support.v4.app.DialogFragment
import android.support.v4.app.FragmentActivity
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.GridView
import android.widget.LinearLayout
import com.sapuseven.untis.R
import com.sapuseven.untis.adapters.GridViewAdapter
import com.sapuseven.untis.helpers.timetable.TimetableDatabaseInterface
import com.sapuseven.untis.models.untis.timetable.PeriodElement

class ElementPickerDialog : DialogFragment() {
	private var timetableDatabaseInterface: TimetableDatabaseInterface? = null
	private var type: String = ""

	private var list: List<PeriodElement> = emptyList()
	private var adapter: GridViewAdapter? = null

	private lateinit var listener: ElementPickerDialogListener

	interface ElementPickerDialogListener {
		fun onDialogDismissed(dialog: DialogInterface?)
		fun onPeriodElementClick(dialog: DialogFragment, element: PeriodElement?)
	}

	override fun onAttach(context: Context) {
		super.onAttach(context)
		if (context is ElementPickerDialogListener)
			listener = context
		else
			throw ClassCastException((context.toString() + " must implement ElementPickerDialogListener"))

		timetableDatabaseInterface?.let { timetableDatabaseInterface ->
			val interfaceType = TimetableDatabaseInterface.Type.valueOf(type)
			list = timetableDatabaseInterface.getElements(type)
			adapter = GridViewAdapter(context, list) {
				timetableDatabaseInterface.getShortName(it.id, interfaceType)
			}
			adapter?.timetableDatabaseInterface = timetableDatabaseInterface
			adapter?.notifyDataSetChanged()
		}
	}

	override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
		return activity?.let { activity ->
			val builder = AlertDialog.Builder(activity)

			builder.setView(generateView(activity))

			builder.create()
		} ?: throw IllegalStateException("Activity cannot be null")
	}

	override fun onDismiss(dialog: DialogInterface?) {
		listener.onDialogDismissed(dialog)
	}

	@SuppressLint("InflateParams")
	private fun generateView(activity: FragmentActivity): View {
		val root = activity.layoutInflater.inflate(R.layout.dialog_element_picker, null) as LinearLayout

		val gridView = root.findViewById<GridView>(R.id.gv)
		gridView.setOnItemClickListener { parent, view, position, id -> listener.onPeriodElementClick(this@ElementPickerDialog, adapter?.itemAt(position)) }
		gridView.adapter = adapter

		root.findViewById<TextInputLayout>(R.id.etLayout).hint = getString(when (type) {
			TimetableDatabaseInterface.Type.CLASS.toString() -> R.string.hint_search_classes
			TimetableDatabaseInterface.Type.TEACHER.toString() -> R.string.hint_search_teachers
			TimetableDatabaseInterface.Type.ROOM.toString() -> R.string.hint_search_rooms
			else -> R.string.hint_search
		})

		val searchField = root.findViewById<TextInputEditText>(R.id.et)
		searchField.addTextChangedListener(object : TextWatcher {
			override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
				adapter?.filter?.filter(s.toString())
			}

			override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

			override fun afterTextChanged(s: Editable) {}
		})

		return root
	}

	companion object {
		fun createInstance(timetableDatabaseInterface: TimetableDatabaseInterface, type: String): ElementPickerDialog {
			val fragment = ElementPickerDialog()
			fragment.timetableDatabaseInterface = timetableDatabaseInterface
			fragment.type = type
			return fragment
		}
	}
}