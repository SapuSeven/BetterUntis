package com.sapuseven.untis.views

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.AttributeSet
import android.util.Log
import android.view.View
import kotlin.math.min

// TODO: Fix Kotlin code
class TimetableGridItemBackground(context: Context, attrs: AttributeSet) : View(context, attrs) {
	private val topPaint = Paint()
	private val bottomPaint = Paint()
	private val dividerPaint = Paint()
	private val indicatorPaint = Paint()
	private val indicatorPath = Path()
	private var dividerPosition: Int = 0
	private var drawIndicator = false
	private var maskPaint: Paint? = null
	private var paint: Paint? = null
	private var maskBitmap: Bitmap? = null
	private var cornerRadius = 0f

	init {
		init()
	}

	private fun init() {
		paint = Paint(Paint.ANTI_ALIAS_FLAG)
		maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
		maskPaint!!.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) // TODO: Prevent from crashing

		setWillNotDraw(false)
	}

	override fun draw(canvas: Canvas) {
		val width = canvas.width
		val height = canvas.height

		if (width == 0 || height == 0) return

		val offscreenBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
		val offscreenCanvas = Canvas(offscreenBitmap)

		super.draw(canvas)

		when (dividerPosition) {
			height -> offscreenCanvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bottomPaint)
			0 -> offscreenCanvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), topPaint)
			else -> {
				offscreenCanvas.drawRect(0f, 0f, width.toFloat(), (height - dividerPosition).toFloat(), topPaint)
				offscreenCanvas.drawRect(0f, (height - dividerPosition).toFloat(), width.toFloat(), height.toFloat(), bottomPaint)
				offscreenCanvas.drawRect(0f, (height - dividerPosition - dp2px(1)).toFloat(), width.toFloat(), (height - dividerPosition + dp2px(1)).toFloat(), dividerPaint)
			}
		}

		if (drawIndicator) {
			if (indicatorPath.isEmpty) {
				indicatorPath.moveTo((width - dp2px(8)).toFloat(), height.toFloat())
				indicatorPath.lineTo(width.toFloat(), height.toFloat())
				indicatorPath.lineTo(width.toFloat(), (height - dp2px(8)).toFloat())
				indicatorPath.close()
			}

			offscreenCanvas.drawPath(indicatorPath, indicatorPaint)
		}

		if (maskBitmap == null)
			maskBitmap = createMask(canvas.width, canvas.height)

		offscreenCanvas.drawBitmap(maskBitmap!!, 0f, 0f, maskPaint) // TODO: Prevent from crashing
		canvas.drawBitmap(offscreenBitmap, 0f, 0f, paint)
	}

	fun setTopColor(topColor: Int) {
		topPaint.color = topColor
	}

	fun setBottomColor(bottomColor: Int) {
		bottomPaint.color = bottomColor
	}

	fun setDividerColor(dividerColor: Int) {
		dividerPaint.color = dividerColor
	}

	fun setDividerPosition(dividerPosition: Int) {
		this.dividerPosition = dividerPosition
	}

	fun setIndicatorColor(color: Int) {
		this.drawIndicator = true
		this.indicatorPaint.style = Paint.Style.FILL
		this.indicatorPaint.color = color
	}

	private fun createMask(width: Int, height: Int): Bitmap {
		val mask = Bitmap.createBitmap(width, height, Bitmap.Config.ALPHA_8)
		val c = Canvas(mask)

		val paint = Paint(Paint.ANTI_ALIAS_FLAG)
		paint.color = Color.WHITE
		c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

		paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
		c.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), cornerRadius, cornerRadius, paint)

		return mask
	}

	fun setCornerRadius(cornerRadiusPx: Float) {
		this.cornerRadius = cornerRadiusPx
	}

	override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
		// Try for a width based on our minimum
		val minw: Int = paddingLeft + paddingRight + suggestedMinimumWidth
		val w: Int = View.resolveSizeAndState(minw, widthMeasureSpec, 1)

		// Whatever the width ends up being, ask for a height that would let the pie
		// get as big as it can
		val minh: Int = View.MeasureSpec.getSize(w) + paddingBottom + paddingTop
		val h: Int = View.resolveSizeAndState(
				View.MeasureSpec.getSize(w),
				heightMeasureSpec,
				0
		)

		//setMeasuredDimension(w, h)
		setMeasuredDimension(0, 0)
	}

	private fun dp2px(value: Int): Int {
		return 2 * value
	}
}