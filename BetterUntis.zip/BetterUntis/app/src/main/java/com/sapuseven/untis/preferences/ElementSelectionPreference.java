package com.sapuseven.untis.preferences;

import android.content.Context;
import android.support.v7.preference.Preference;
import android.util.AttributeSet;

public class ElementSelectionPreference extends /*DialogPreference */ Preference {
	public ElementSelectionPreference(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		super(context, attrs, defStyleAttr, defStyleRes);
	}

	public ElementSelectionPreference(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
	}

	public ElementSelectionPreference(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public ElementSelectionPreference(Context context) {
		super(context);
	}
	/*private static final int COMPOUND_DRAWABLE_LEFT = 0;
	private static final int COMPOUND_DRAWABLE_TOP = 1;
	private static final int COMPOUND_DRAWABLE_RIGHT = 2;
	private static final int COMPOUND_DRAWABLE_BOTTOM = 3;

	private TextView tvPersonal;
	private TextView tvClasses;
	private TextView tvTeachers;
	private TextView tvRooms;

	private ElementName.ElementType selectedType = UNKNOWN;
	private String selectedName;
	private int selectedId = -1;
	private int selectedPosition = -1;

	private ColorStateList defaultTextColor;
	private ColorStateList defaultItemTextColor;
	private ElementSelectionListHelper helper;
	private ViewGroup elemList;
	private AlertDialog dialog;

	public ElementSelectionPreference(Context context, AttributeSet attrs) {
		super(context, attrs);
		setDialogLayoutResource(R.layout.dialog_element_selection);
	}

	@Override
	protected void showDialog(Bundle state) {
		super.showDialog(state);

		dialog = ((AlertDialog) getDialog());
	}

	@Override
	protected void onBindDialogView(View view) {
		super.onBindDialogView(view);

		tvTeachers = view.findViewById(R.id.tvTeachers);
		tvPersonal = view.findViewById(R.id.tvPersonal);
		tvClasses = view.findViewById(R.id.tvClasses);
		tvRooms = view.findViewById(R.id.tvRooms);

		defaultTextColor = tvPersonal.getTextColors();

		tvPersonal.setOnClickListener(v -> {
			if (selectedType != UNKNOWN) {
				selectedType = UNKNOWN;
				updateSelection();
			}
		});

		tvClasses.setOnClickListener(v -> {
			if (selectedType != CLASS) {
				selectedType = CLASS;
				updateSelection();
			}
		});

		tvTeachers.setOnClickListener(v -> {
			if (selectedType != TEACHER) {
				selectedType = TEACHER;
				updateSelection();
			}
		});

		tvRooms.setOnClickListener(v -> {
			if (selectedType != ROOM) {
				selectedType = ROOM;
				updateSelection();
			}
		});

		elemList = view.findViewById(R.id.elemList);

		helper = new ElementSelectionListHelper((Activity) getContext()) {
			@Override
			public void onItemSelected(int position) {
				super.onItemSelected(position);

				final ElementName elementName = new ElementName(selectedType, getUserDataList());
				final List<String> list = getList();
				try {
					selectedName = list.get(position);
					selectedId = (int) elementName.findFieldByValue("name", list.get(position), "id");

					int oldPosition = selectedPosition;
					selectedPosition = position;

					updateView(oldPosition);
					updateView(selectedPosition);
				} catch (JSONException e) {
					e.printStackTrace(); // Not expected to occur, but TODO: Handle this error anyways
				}
			}

			@Override
			public void applyStyling(View view, int position) {
				super.applyStyling(view, position);

				refreshStyling(view, position);
			}
		};

		helper.setUserDataList(ListManager.getUserData(getContext()));

		try {
			helper.setSourceField("rooms");

			elemList.addView(helper.getView(R.string.filter_items));
		} catch (JSONException e) {
			e.printStackTrace();
		}

		SharedPreferences sharedPrefs = getSharedPreferences();
		selectedType = fromValue(sharedPrefs.getInt(getKey(), UNKNOWN.value));
		selectedId = sharedPrefs.getInt(getKey() + "_id", -1);
		selectedName = sharedPrefs.getString(getKey() + "_name", "");

		updateSelection();

		selectedPosition = helper.getList().indexOf(selectedName);
		updateView(selectedPosition);

		setPositiveButtonText(R.string.ok);
		setNegativeButtonText(R.string.cancel);
	}

	private void refreshStyling(View view, int position) {
		if (defaultItemTextColor == null)
			defaultItemTextColor = ((TextView) view).getTextColors();

		if (selectedPosition == position)
			((TextView) view).setTextColor(getContext().getResources().getColor(R.color.colorPrimary));
		else
			((TextView) view).setTextColor(defaultItemTextColor);

		checkIfValid();
	}

	private void checkIfValid() {
		if (dialog != null)
			dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled((selectedType == UNKNOWN || selectedPosition >= 0));
	}

	private void updateView(int position) {
		GridView gridView = helper.getView().findViewById(R.id.gv);

		if (position >= gridView.getFirstVisiblePosition() && position <= gridView.getLastVisiblePosition())
			refreshStyling(gridView.getChildAt(position - gridView.getFirstVisiblePosition()), position);
	}

	private void updateSelection() {
		deselect(tvPersonal);
		deselect(tvClasses);
		deselect(tvTeachers);
		deselect(tvRooms);

		select(getTextViewFromElemType(selectedType.value));

		refreshElemList();

		checkIfValid();
	}

	private TextView getTextViewFromElemType(int elemType) {
		switch (fromValue(elemType)) {
			case CLASS:
				return tvClasses;
			case TEACHER:
				return tvTeachers;
			case ROOM:
				return tvRooms;
			case UNKNOWN:
			default:
				return tvPersonal;
		}
	}

	private void select(TextView tv) {
		deselect(tvPersonal);
		deselect(tvClasses);
		deselect(tvTeachers);
		deselect(tvRooms);

		int oldPosition = selectedPosition;
		selectedPosition = -1;
		updateView(oldPosition);

		tv.setTextColor(getContext().getResources().getColor(R.color.colorPrimary));
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
			tv.getCompoundDrawables()[COMPOUND_DRAWABLE_TOP].setTint(getContext().getResources().getColor(R.color.colorPrimary));
	}

	private void refreshElemList() {
		try {
			elemList.setVisibility(View.VISIBLE);
			switch (selectedType) {
				case CLASS:
					helper.setSourceField("klassen");
					break;
				case TEACHER:
					helper.setSourceField("teachers");
					break;
				case ROOM:
					helper.setSourceField("rooms");
					break;
				default:
					elemList.setVisibility(GONE);
					break;
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void deselect(TextView tv) {
		tv.setTextColor(defaultTextColor);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
			tv.getCompoundDrawables()[COMPOUND_DRAWABLE_TOP].setTintList(null);
	}

	@Override
	protected void onDialogClosed(boolean positiveResult) {
		super.onDialogClosed(positiveResult);

		if (positiveResult) {
			saveSelected();
			if (selectedType != UNKNOWN)
				setSummary(selectedName);
			else
				setSummary("");
		}
	}

	@Override
	protected Object onGetDefaultValue(TypedArray a, int index) {
		return super.onGetDefaultValue(a, index);
	}

	@Override
	public CharSequence getSummary() {
		if (selectedName == null) {
			SharedPreferences sharedPrefs = getSharedPreferences();
			selectedType = fromValue(sharedPrefs.getInt(getKey(), UNKNOWN.value));
			selectedId = sharedPrefs.getInt(getKey() + "_id", -1);
			selectedName = sharedPrefs.getString(getKey() + "_name", "");
		}

		if (selectedType != UNKNOWN)
			return selectedName;
		else
			return "";
		// I am not sure if I should really override getSummary AND use setSummary.
		// Help would be appreciated.
	}

	private void saveSelected() {
		SharedPreferences.Editor editor = getEditor();
		editor.putInt(getKey(), selectedType.value);
		editor.putInt(getKey() + "_id", selectedId);
		editor.putString(getKey() + "_name", selectedName);
		editor.commit();
	}*/
}
