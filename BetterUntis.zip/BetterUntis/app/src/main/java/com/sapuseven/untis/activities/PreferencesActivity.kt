package com.sapuseven.untis.activities

import android.content.Context
import android.preference.PreferenceManager
class PreferencesActivity /*: PreferencesAppCompatActivity()*/ {

	/*override fun onCreate(savedInstanceState: Bundle) {
		//setupTheme(this, true)
		super.onCreate(savedInstanceState)
		setupActionBar()
		//setupBackground(this)
	}

	private fun setupActionBar() {
		val actionBar = getSupportActionBar()
		actionBar.setDisplayHomeAsUpEnabled(true)
	}

	override fun onBuildHeaders(target: List<Header>) {
		loadHeadersFromResource(R.xml.prefs_headers, target)

		val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this)

		if (sharedPrefs.getBoolean("preference_dark_theme_amoled", false) && sharedPrefs.getBoolean("preference_dark_theme", false))
			getListView().setBackgroundColor(Color.BLACK)
	}

	override fun isValidFragment(fragmentName: String): Boolean {
		return (PreferenceFragment::class.java.name == fragmentName/*
				|| StylingFragment::class.java.name == fragmentName
				|| NotificationsFragment::class.java.name == fragmentName
				|| RoomFinderFragment::class.java.name == fragmentName
				|| TimetableFragment::class.java.name == fragmentName
				|| AccountFragment::class.java.name == fragmentName
				|| AboutFragment::class.java.name == fragmentName*/)
	}

	override fun onMenuItemSelected(featureId: Int, item: MenuItem): Boolean {
		val id = item.itemId
		if (id == android.R.id.home) {
			if (!super.onMenuItemSelected(featureId, item))
				finish()
			return true
		}
		return super.onMenuItemSelected(featureId, item)
	}

	fun onColorSelected(dialogId: Int, color: Int) {
		sStylingFragment!!.onColorSelected(dialogId, color)
	}

	fun onDialogDismissed(dialogId: Int) {
		sStylingFragment!!.onDialogDismissed(dialogId)
	}

	class StylingFragment : PreferenceFragment(), ColorPickerDialogFragment.ColorPickerDialogListener {
		private var toast: BetterToast? = null
		private var resetColorsListener: Preference.OnPreferenceClickListener? = null
		private var colorPrefs: ColorPreferenceList? = null

		override fun onCreate(savedInstanceState: Bundle?) {
			super.onCreate(savedInstanceState)
			toast = BetterToast(this.activity)
			addPreferencesFromResource(R.xml.prefs_styling)
			sStylingFragment = this
			resetColorsListener = { preference ->
				val editor = PreferenceManager
						.getDefaultSharedPreferences(this@StylingFragment.activity).edit()
				editor.remove("preference_background_regular").apply()
				editor.remove("preference_background_regular_past").apply()
				editor.remove("preference_background_exam").apply()
				editor.remove("preference_background_exam_past").apply()
				editor.remove("preference_background_irregular").apply()
				editor.remove("preference_background_irregular_past").apply()
				editor.remove("preference_background_cancelled").apply()
				editor.remove("preference_background_cancelled_past").apply()
				editor.remove("preference_background_free").apply()
				editor.remove("preference_marker").apply()
				toast!!.showToast(R.string.toast_colors_reset, Toast.LENGTH_LONG)
				preferenceScreen = null
				addPreferencesFromResource(R.xml.prefs_styling)
				setupEverything()
				restartOnExit(activity)
				true
			}
			setupEverything()
		}

		private fun setupEverything() {
			setupEnabledItemsOnThemeBackground(
					preferenceManager.sharedPreferences
							.getBoolean("preference_use_theme_background",
									resources.getBoolean(
											resources.getIdentifier("preference_use_theme_background_default", "bool", activity.packageName)
									)
							)
			)
			setupChangeListeners()
		}

		private fun setupChangeListeners() {
			setupColorPickers()

			val preferencesNeedingRefresh = arrayOf("preference_alternating_days", "preference_alternating_hours", "preference_alternating_colors_use_custom", "preference_timetable_item_text_light", "preference_use_default_background", "preference_use_theme_background", "preference_timetable_colors_reset", "preference_timetable_hide_cancelled", "preference_theme", "preference_dark_theme", "preference_dark_theme_amoled")

			for (prefKey in preferencesNeedingRefresh)
				findPreference(prefKey).setOnPreferenceChangeListener { preference, newValue ->
					restartOnExit(activity)
					true
				}

			findPreference("preference_use_theme_background").setOnPreferenceChangeListener { preference, newValue ->
				setupEnabledItemsOnThemeBackground(newValue as Boolean)
				true
			}
		}

		private fun setupEnabledItemsOnThemeBackground(preferenceStatus: Boolean) {
			findPreference("preference_background_regular").isEnabled = !preferenceStatus
			findPreference("preference_background_regular_past").isEnabled = !preferenceStatus
		}

		private fun setupColorPickers() {
			colorPrefs = ColorPreferenceList()
			colorPrefs!!.add("preference_background_regular")
			colorPrefs!!.add("preference_background_regular_past")
			colorPrefs!!.add("preference_background_irregular")
			colorPrefs!!.add("preference_background_irregular_past")
			colorPrefs!!.add("preference_background_cancelled")
			colorPrefs!!.add("preference_background_cancelled_past")
			colorPrefs!!.add("preference_background_exam")
			colorPrefs!!.add("preference_background_exam_past")
			colorPrefs!!.add("preference_background_free")
			colorPrefs!!.add("preference_marker")
			colorPrefs!!.add("preference_alternating_color")

			for (i in 0 until colorPrefs!!.size()) {
				val key = colorPrefs!!.getKey(i)
				(findPreference(key) as ColorPreference).setOnShowDialogListener(
						{ title, currentColor ->
							ColorPickerDialogFragment.Builder(i, currentColor)
									.title(title)
									.showHexadecimalInput()
									.build()
									.show(fragmentManager, key + "_dialog")
						})
			}

			val reset = findPreference("preference_timetable_colors_reset")
			reset.onPreferenceClickListener = resetColorsListener
		}

		override fun onOptionsItemSelected(item: MenuItem): Boolean {
			val id = item.itemId
			if (id == android.R.id.home) {
				startActivity(Intent(activity, ActivityPreferences::class.java))
				return true
			}
			return super.onOptionsItemSelected(item)
		}

		fun onColorSelected(dialogId: Int, color: Int) {
			val pref = findPreference(colorPrefs!!.getKey(dialogId)) as ColorPreference

			if (pref != null) {
				pref!!.saveValue(color)
				restartOnExit(activity)
			}
		}

		fun onDialogDismissed(dialogId: Int) {
			// No changes
		}
	}

	class NotificationsFragment : PreferenceFragment() {

		override fun onCreate(savedInstanceState: Bundle?) {
			super.onCreate(savedInstanceState)
			addPreferencesFromResource(R.xml.prefs_notifications)

			findPreference("preference_notifications_enable").setOnPreferenceClickListener { preference ->
				if (!preference.isEnabled) {
					val notificationManager = activity
							.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
					notificationManager?.cancelAll()
				}
				true
			}

			findPreference("preference_notifications_clear").setOnPreferenceClickListener { preference ->
				if (!preference.isEnabled) {
					val notificationManager = activity
							.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
					notificationManager?.cancelAll()
				}
				true
			}
		}

		override fun onOptionsItemSelected(item: MenuItem): Boolean {
			val id = item.itemId
			if (id == android.R.id.home) {
				startActivity(Intent(activity, ActivityPreferences::class.java))
				return true
			}
			return super.onOptionsItemSelected(item)
		}
	}

	class RoomFinderFragment : PreferenceFragment() {

		override fun onCreate(savedInstanceState: Bundle?) {
			super.onCreate(savedInstanceState)
			addPreferencesFromResource(R.xml.prefs_roomfinder)

			val roomList = ActivityRoomFinder.getRooms(activity, true)
					.toArray(arrayOfNulls<String>(0))
			(findPreference("preference_room_to_display_in_free_lessons") as ListPreference)
					.setEntries(roomList)
			(findPreference("preference_room_to_display_in_free_lessons") as ListPreference)
					.setEntryValues(roomList)

			findPreference("preference_room_to_display_in_free_lessons")
					.setOnPreferenceChangeListener { preference, newValue ->
						restartOnExit(activity)
						true
					}

			findPreference("preference_room_to_display_in_free_lessons_trim")
					.setOnPreferenceChangeListener { preference, newValue ->
						restartOnExit(activity)
						true
					}
		}

		override fun onOptionsItemSelected(item: MenuItem): Boolean {
			val id = item.itemId
			if (id == android.R.id.home) {
				startActivity(Intent(activity, ActivityPreferences::class.java))
				return true
			}

			return super.onOptionsItemSelected(item)
		}
	}

	class AccountFragment : PreferenceFragment() {
		private var toast: BetterToast? = null

		override fun onCreate(savedInstanceState: Bundle?) {
			super.onCreate(savedInstanceState)
			toast = BetterToast(this.activity)
			addPreferencesFromResource(R.xml.prefs_account)

			val prefs = activity
					.getSharedPreferences("loginData", MODE_PRIVATE)
			val prefKey = findPreference("preference_account_access_key")
			prefKey.summary = prefs.getString("key", "UNKNOWN")
			prefKey.setOnPreferenceClickListener { preference ->
				val clipboard = activity
						.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
				if (clipboard != null) {
					val clip = ClipData.newPlainText(getString(R.string.preference_account_access_key),
							prefs.getString("key", "UNKNOWN"))
					clipboard.primaryClip = clip
					toast!!.showToast(R.string.key_copied, Toast.LENGTH_SHORT)
					return@prefKey.setOnPreferenceClickListener true
				} else {
					toast!!.showToast(R.string.key_copy_failed, Toast.LENGTH_SHORT)
					return@prefKey.setOnPreferenceClickListener false
				}
			}

			val prefFirebaseKey = findPreference("preference_account_firebase_key")
			if (BuildConfig.ENABLE_FIREBASE) {
				prefFirebaseKey.setSummary(FirebaseInstanceId.getInstance().getToken())
			} else {
				prefFirebaseKey.summary = "(disabled)"
			}
			prefFirebaseKey.setOnPreferenceClickListener { preference ->
				val clipboard = activity
						.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
				if (clipboard != null) {
					@SuppressLint("MissingFirebaseInstanceTokenRefresh") val clip = ClipData.newPlainText(getString(R.string.firebase_key),
							FirebaseInstanceId.getInstance().getToken())
					clipboard.primaryClip = clip
					toast!!.showToast(R.string.key_copied, Toast.LENGTH_SHORT)
					return@prefFirebaseKey.setOnPreferenceClickListener true
				} else {
					toast!!.showToast(R.string.key_copy_failed, Toast.LENGTH_SHORT)
					return@prefFirebaseKey.setOnPreferenceClickListener false
				}
			}

			findPreference("preference_account_logout").setOnPreferenceClickListener { preference ->
				// TODO: Display a confirmation dialog
				activity.getSharedPreferences("loginData", MODE_PRIVATE)
						.edit().clear().apply()
				val lm = ListManager(activity)
				lm.delete("userData", false)
				lm.invalidateCaches()
				restartApplication(activity)
				true
			}
		}

		override fun onOptionsItemSelected(item: MenuItem): Boolean {
			val id = item.itemId
			if (id == android.R.id.home) {
				startActivity(Intent(activity, ActivityPreferences::class.java))
				return true
			}

			return super.onOptionsItemSelected(item)
		}
	}

	class TimetableFragment : PreferenceFragment() {

		override fun onCreate(savedInstanceState: Bundle?) {
			super.onCreate(savedInstanceState)
			addPreferencesFromResource(R.xml.prefs_timetable)

			val preferencesNeedingRefresh = arrayOf("preference_timetable_item_padding", "preference_timetable_item_corner_radius", "preference_timetable_centered_lesson_info", "preference_timetable_bold_lesson_name", "preference_timetable_lesson_name_font_size", "preference_timetable_lesson_info_font_size")

			for (prefKey in preferencesNeedingRefresh)
				findPreference(prefKey).setOnPreferenceChangeListener { preference, newValue ->
					restartOnExit(activity)
					true
				}

			val pref = findPreference("preference_timetable_personal_timetable")
			pref.summary = pref.summary
			pref.setOnPreferenceClickListener { preference ->
				restartOnExit(activity)
				true
			}
		}

		override fun onOptionsItemSelected(item: MenuItem): Boolean {
			val id = item.itemId
			if (id == android.R.id.home) {
				startActivity(Intent(activity, ActivityPreferences::class.java))
				return true
			}

			return super.onOptionsItemSelected(item)
		}
	}

	class AboutFragment : PreferenceFragment() {
		private var clicks: Int = 0

		override fun onCreate(savedInstanceState: Bundle?) {
			super.onCreate(savedInstanceState)
			addPreferencesFromResource(R.xml.prefs_about)
			findPreference("preference_info_contact_email").setOnPreferenceClickListener { preference ->
				val prefs = activity
						.getSharedPreferences("loginData", MODE_PRIVATE)
				val i3 = Intent(Intent.ACTION_SEND)
				i3.type = "plain/text"
				i3.putExtra(Intent.EXTRA_EMAIL,
						arrayOf(getString(R.string.contact_email)))
				i3.putExtra(Intent.EXTRA_SUBJECT, "BetterUntis Feedback from user " + prefs.getString("user", "UNKNOWN")!!)
				startActivity(Intent.createChooser(i3, getString(R.string.give_feedback)))
				true
			}

			val prefVersion = findPreference("preference_info_app_version")
			prefVersion.summary = getString(R.string.app_version_full,
					BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE)
			prefVersion.setOnPreferenceClickListener { preference ->
				clicks++
				if (clicks > BuildConfig.VERSION_CODE)
					prefVersion.summary = getString(R.string.app_version_full, BuildConfig.VERSION_NAME, clicks)
				true
			}

			findPreference("preference_info_changelog").setOnPreferenceClickListener { preference ->
				DisplayChangelog(activity)
						.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 0)
				true
			}

			findPreference("preference_send_stats").setOnPreferenceClickListener { preference ->
				// TODO: Disable the Preference and send a request to the server with the current settings and the message to log out.
				// After that re-enable the preference and show a toast like "You opted out".
				false
			}

			findPreference("preference_info_stats").setOnPreferenceClickListener { preference ->
				// TODO: Show a dialog with this information
				false
			}
		}

		override fun onOptionsItemSelected(item: MenuItem): Boolean {
			val id = item.itemId
			if (id == android.R.id.home) {
				startActivity(Intent(activity, ActivityPreferences::class.java))
				return true
			}
			return super.onOptionsItemSelected(item)
		}
	}*/

	companion object {
		//private var sStylingFragment: StylingFragment? = null

		private fun restartOnExit(context: Context) {
			val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context)
			val editor = sharedPrefs.edit()
			editor.putBoolean("restart", true)
			editor.apply()
		}
	}
}