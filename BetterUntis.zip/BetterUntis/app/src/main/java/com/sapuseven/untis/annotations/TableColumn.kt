package com.sapuseven.untis.annotations

annotation class TableColumn(val type: String)
